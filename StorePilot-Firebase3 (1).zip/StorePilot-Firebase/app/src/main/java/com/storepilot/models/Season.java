package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import java.util.Date;

public class Season {

    @DocumentId
    private String id;
    private String name;
    private Date startDate;
    private Date endDate;
    private int alertDaysBeforeEnd;
    private boolean isActive;
    private String notes;

    public Season() {}

    public Season(String name, Date startDate, Date endDate,
                  int alertDaysBeforeEnd, boolean isActive, String notes) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.alertDaysBeforeEnd = alertDaysBeforeEnd;
        this.isActive = isActive;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String v) { this.id = v; }
    public String getName() { return name; }
    public void setName(String v) { this.name = v; }
    public Date getStartDate() { return startDate; }
    public void setStartDate(Date v) { this.startDate = v; }
    public Date getEndDate() { return endDate; }
    public void setEndDate(Date v) { this.endDate = v; }
    public int getAlertDaysBeforeEnd() { return alertDaysBeforeEnd; }
    public void setAlertDaysBeforeEnd(int v) { this.alertDaysBeforeEnd = v; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean v) { this.isActive = v; }
    public String getNotes() { return notes; }
    public void setNotes(String v) { this.notes = v; }
}
