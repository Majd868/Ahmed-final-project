package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Season;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeasonRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    public LiveData<List<Season>> getAllSeasons() {
        MutableLiveData<List<Season>> ld = new MutableLiveData<>();
        fm.seasonsCollection()
                .orderBy("startDate", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Season.class));
                });
        return ld;
    }

    public LiveData<Season> getById(String seasonId) {
        MutableLiveData<Season> ld = new MutableLiveData<>();
        fm.seasonsCollection().document(seasonId)
                .addSnapshotListener((doc, e) -> {
                    if (doc != null && doc.exists()) ld.setValue(doc.toObject(Season.class));
                    else ld.setValue(null);
                });
        return ld;
    }

    /** المواسم التي تنتهي قريباً (نشطة وتاريخ نهايتها قريب) */
    public LiveData<List<Season>> getSeasonsEndingSoon() {
        MutableLiveData<List<Season>> ld = new MutableLiveData<>();
        fm.seasonsCollection()
                .whereEqualTo("active", true)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    List<Season> endingSoon = new ArrayList<>();
                    long now = System.currentTimeMillis();
                    for (Season s : snap.toObjects(Season.class)) {
                        if (s.getEndDate() != null) {
                            long alertMs = (long) s.getAlertDaysBeforeEnd() * 24 * 60 * 60 * 1000;
                            if (s.getEndDate().getTime() <= now + alertMs) {
                                endingSoon.add(s);
                            }
                        }
                    }
                    ld.setValue(endingSoon);
                });
        return ld;
    }

    public LiveData<Boolean> insert(Season season) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.seasonsCollection().add(season)
                .addOnSuccessListener(r -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> update(Season season) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.seasonsCollection().document(season.getId()).set(season)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(Season season) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.seasonsCollection().document(season.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }
}
