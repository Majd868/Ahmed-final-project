package com.storepilot.purchases;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.Purchase;
import com.storepilot.repositories.SessionManager;
import com.storepilot.viewmodels.PurchaseViewModel;
import java.text.SimpleDateFormat;
import java.util.*;

public class PurchaseHistoryFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_purchase_history, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerPurchases);
        PurchaseAdapter adapter = new PurchaseAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        PurchaseViewModel vm = new ViewModelProvider(this).get(PurchaseViewModel.class);
        vm.getAllPurchases().observe(getViewLifecycleOwner(), adapter::setPurchases);
        view.findViewById(R.id.fabAddPurchase).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), AddPurchaseActivity.class)));
    }
}

class PurchaseAdapter extends RecyclerView.Adapter<PurchaseAdapter.VH> {
    private List<Purchase> list = new ArrayList<>();
    public void setPurchases(List<Purchase> l) { list = l != null ? l : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_purchase, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Purchase p = list.get(pos);
        h.tvDate.setText(p.getPurchaseDate() != null ? new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(p.getPurchaseDate()) : "");
        h.tvTotal.setText(String.format("$%.2f", p.getTotalCost()));
        h.tvSupplier.setText(p.getSupplier() != null ? p.getSupplier() : "");
        h.tvQty.setText("Qty: " + p.getQuantity());
    }
    @Override public int getItemCount() { return list.size(); }
    static class VH extends RecyclerView.ViewHolder {
        TextView tvDate, tvTotal, tvSupplier, tvQty;
        VH(View v) { super(v); tvDate=v.findViewById(R.id.tvPurchaseDate); tvTotal=v.findViewById(R.id.tvPurchaseTotal); tvSupplier=v.findViewById(R.id.tvPurchaseSupplier); tvQty=v.findViewById(R.id.tvPurchaseQty); }
    }
}

class AddPurchaseActivity extends BaseActivity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_add_purchase);
        EditText etPid=findViewById(R.id.etPurchaseProductId), etQty=findViewById(R.id.etPurchaseQuantity),
                etCost=findViewById(R.id.etPurchaseTotalCost), etSupp=findViewById(R.id.etPurchaseSupplier),
                etNote=findViewById(R.id.etPurchaseNotes);
        PurchaseViewModel vm = new ViewModelProvider(this).get(PurchaseViewModel.class);
        findViewById(R.id.btnSavePurchase).setOnClickListener(v -> {
            if (etPid.getText().toString().isEmpty()||etQty.getText().toString().isEmpty()||etCost.getText().toString().isEmpty()) {
                Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show(); return;
            }
            String uid = SessionManager.getInstance().getCurrentUserId();
            Purchase p = new Purchase(etPid.getText().toString().trim(), "",
                    Integer.parseInt(etQty.getText().toString()),
                    Double.parseDouble(etCost.getText().toString()),
                    uid, etSupp.getText().toString().trim(), etNote.getText().toString().trim());
            vm.insert(p).observe(this, ok -> { if (Boolean.TRUE.equals(ok)) finish(); });
        });
    }
}
