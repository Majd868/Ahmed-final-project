// ==================== SeasonListFragment ====================
package com.storepilot.seasons;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.Season;
import com.storepilot.viewmodels.SeasonViewModel;
import java.text.SimpleDateFormat;
import java.util.*;

public class SeasonListFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_season_list, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerSeasons);
        FloatingActionButton fab = view.findViewById(R.id.fabAddSeason);
        SeasonAdapter adapter = new SeasonAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        SeasonViewModel vm = new ViewModelProvider(this).get(SeasonViewModel.class);
        vm.getAllSeasons().observe(getViewLifecycleOwner(), adapter::setSeasons);
        fab.setOnClickListener(v -> startActivity(new Intent(getActivity(), AddEditSeasonActivity.class)));
    }
}

class SeasonAdapter extends RecyclerView.Adapter<SeasonAdapter.VH> {
    private List<Season> list = new ArrayList<>();
    public void setSeasons(List<Season> l) { list = l != null ? l : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_season, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Season s = list.get(pos);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        h.tvName.setText(s.getName());
        String dates = (s.getStartDate() != null ? sdf.format(s.getStartDate()) : "") + " - " +
                       (s.getEndDate() != null ? sdf.format(s.getEndDate()) : "");
        h.tvDates.setText(dates);
        h.tvActive.setText(s.isActive() ? "Active" : "Inactive");
    }
    @Override public int getItemCount() { return list.size(); }
    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvDates, tvActive;
        VH(View v) { super(v); tvName=v.findViewById(R.id.tvSeasonName); tvDates=v.findViewById(R.id.tvSeasonDates); tvActive=v.findViewById(R.id.tvSeasonActive); }
    }
}

class AddEditSeasonActivity extends BaseActivity {
    public static final String EXTRA_SEASON_ID = "season_id";
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_add_edit_season);
        EditText etName=findViewById(R.id.etSeasonName), etStart=findViewById(R.id.etSeasonStartDate),
                etEnd=findViewById(R.id.etSeasonEndDate), etAlert=findViewById(R.id.etAlertDays),
                etNote=findViewById(R.id.etSeasonNotes);
        CheckBox cb=findViewById(R.id.cbSeasonActive);
        SeasonViewModel vm = new ViewModelProvider(this).get(SeasonViewModel.class);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        findViewById(R.id.btnSaveSeason).setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) { Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show(); return; }
            try {
                Date start = sdf.parse(etStart.getText().toString().trim());
                Date end   = sdf.parse(etEnd.getText().toString().trim());
                int alert  = etAlert.getText().toString().isEmpty() ? 30 : Integer.parseInt(etAlert.getText().toString());
                Season season = new Season(name, start, end, alert, cb.isChecked(), etNote.getText().toString().trim());
                vm.insert(season).observe(this, ok -> { if (Boolean.TRUE.equals(ok)) finish(); });
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_invalid_date), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
