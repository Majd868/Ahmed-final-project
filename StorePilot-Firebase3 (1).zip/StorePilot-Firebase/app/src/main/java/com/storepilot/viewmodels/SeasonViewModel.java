package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Season;
import com.storepilot.repositories.SeasonRepository;
import java.util.List;

public class SeasonViewModel extends AndroidViewModel {
    private final SeasonRepository repo;
    public SeasonViewModel(@NonNull Application app) { super(app); repo = new SeasonRepository(); }
    public LiveData<List<Season>> getAllSeasons() { return repo.getAllSeasons(); }
    public LiveData<Season> getById(String id) { return repo.getById(id); }
    public LiveData<List<Season>> getSeasonsEndingSoon() { return repo.getSeasonsEndingSoon(); }
    public LiveData<Boolean> insert(Season s) { return repo.insert(s); }
    public LiveData<Boolean> update(Season s) { return repo.update(s); }
    public LiveData<Boolean> delete(Season s) { return repo.delete(s); }
}
