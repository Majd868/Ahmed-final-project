package com.storepilot.repositories;

import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.User;

/**
 * SessionManager - إدارة جلسة المستخدم الحالي
 *
 * Firebase Auth يحفظ الجلسة تلقائياً حتى بعد إغلاق التطبيق.
 * هذا الكلاس يُخزن بيانات المستخدم في الذاكرة للوصول السريع.
 */
public class SessionManager {

    private static SessionManager instance;
    private User currentUser;

    private SessionManager() {}

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void clearUser() {
        currentUser = null;
    }

    public boolean isLoggedIn() {
        // Firebase Auth يتحقق من الجلسة الحقيقية
        return FirebaseManager.getInstance().isLoggedIn();
    }

    public String getUserRole() {
        if (currentUser != null) return currentUser.getRole();
        return null;
    }

    public String getCurrentUserId() {
        return FirebaseManager.getInstance().getCurrentUserId();
    }

    public String getCurrentUsername() {
        if (currentUser != null) return currentUser.getUsername();
        return null;
    }
}
