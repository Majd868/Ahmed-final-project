package com.storepilot.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import com.storepilot.MainActivity;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.repositories.SessionManager;
import com.storepilot.viewmodels.AuthViewModel;

public class LoginActivity extends BaseActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private ProgressBar progressBar;
    private TextView tvDemoHint;
    private AuthViewModel authViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Firebase Auth يحفظ الجلسة تلقائياً - إذا كان مسجلاً دخوله انتقل مباشرة
        if (SessionManager.getInstance().isLoggedIn()) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_login);

        etUsername   = findViewById(R.id.etUsername);
        etPassword   = findViewById(R.id.etPassword);
        btnLogin     = findViewById(R.id.btnLogin);
        progressBar  = findViewById(R.id.progressBar);
        tvDemoHint   = findViewById(R.id.tvDemoHint);

        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        // مراقبة الحالة
        authViewModel.needsSetup.observe(this, needsSetup -> {
            if (Boolean.TRUE.equals(needsSetup)) {
                startActivity(new Intent(this, SetupActivity.class));
                finish();
            }
        });

        authViewModel.loginSuccess.observe(this, success -> {
            if (Boolean.TRUE.equals(success)) {
                goToMain();
            }
        });

        authViewModel.loginError.observe(this, error -> {
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            }
        });

        authViewModel.isLoading.observe(this, loading -> {
            progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
            btnLogin.setEnabled(!loading);
        });

        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_fill_all_fields),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            authViewModel.login(username, password);
        });

        // تحقق من الحاجة للإعداد
        authViewModel.checkNeedsSetup();
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
