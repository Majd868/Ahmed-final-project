package com.storepilot.inventory;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.storepilot.R;
import com.storepilot.viewmodels.ProductViewModel;

public class ProductDetailsFragment extends Fragment {

    private static final String ARG_PRODUCT_ID = "productId";

    public static ProductDetailsFragment newInstance(String productId) {
        ProductDetailsFragment f = new ProductDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PRODUCT_ID, productId);
        f.setArguments(args);
        return f;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product_details, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        String productId = getArguments() != null ? getArguments().getString(ARG_PRODUCT_ID) : null;
        if (productId == null) return;

        TextView tvName     = view.findViewById(R.id.tvDetailName);
        TextView tvCategory = view.findViewById(R.id.tvDetailCategory);
        TextView tvSize     = view.findViewById(R.id.tvDetailSize);
        TextView tvColor    = view.findViewById(R.id.tvDetailColor);
        TextView tvQty      = view.findViewById(R.id.tvDetailQuantity);
        TextView tvPrice    = view.findViewById(R.id.tvDetailPrice);
        TextView tvCost     = view.findViewById(R.id.tvDetailCostPrice);

        ProductViewModel vm = new ViewModelProvider(this).get(ProductViewModel.class);
        vm.getById(productId).observe(getViewLifecycleOwner(), product -> {
            if (product != null) {
                tvName.setText(product.getName());
                tvCategory.setText(product.getCategory());
                tvSize.setText(product.getSize());
                tvColor.setText(product.getColor());
                tvQty.setText(String.valueOf(product.getQuantity()));
                tvPrice.setText(String.format("$%.2f", product.getPrice()));
                tvCost.setText(String.format("$%.2f", product.getCostPrice()));
            }
        });
    }
}
