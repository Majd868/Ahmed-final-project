package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Sale;
import com.storepilot.repositories.SaleRepository;
import java.util.List;

public class SaleViewModel extends AndroidViewModel {
    private final SaleRepository repo;

    public SaleViewModel(@NonNull Application app) {
        super(app);
        repo = new SaleRepository();
    }

    public LiveData<List<Sale>> getAllSales() { return repo.getAllSales(); }
    public LiveData<Double> getTodaySalesTotal() { return repo.getTodaySalesTotal(); }
    public LiveData<Double> getSalesTotalByWeek() { return repo.getSalesTotalByWeek(); }
    public LiveData<Double> getSalesTotalByMonth() { return repo.getSalesTotalByMonth(); }
    public LiveData<Double> getSalesTotalByYear() { return repo.getSalesTotalByYear(); }
    public LiveData<Boolean> insert(Sale s) { return repo.insert(s); }
    public LiveData<Boolean> update(Sale s) { return repo.update(s); }
    public LiveData<Boolean> delete(Sale s) { return repo.delete(s); }
}
