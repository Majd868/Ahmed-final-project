package com.storepilot.sales;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.storepilot.R;
import com.storepilot.models.Sale;
import java.text.SimpleDateFormat;
import java.util.*;

public class SaleAdapter extends RecyclerView.Adapter<SaleAdapter.ViewHolder> {
    private List<Sale> sales = new ArrayList<>();
    public void setSales(List<Sale> list) { this.sales = list != null ? list : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new ViewHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_sale, p, false));
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        Sale s = sales.get(pos);
        h.tvDate.setText(s.getSaleDate() != null ? new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(s.getSaleDate()) : "");
        h.tvTotal.setText(String.format("$%.2f", s.getTotalPrice()));
        h.tvQty.setText("Qty: " + s.getQuantity());
        h.tvNotes.setText(s.getNotes() != null ? s.getNotes() : "");
    }
    @Override public int getItemCount() { return sales.size(); }
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvTotal, tvQty, tvNotes;
        ViewHolder(View v) { super(v); tvDate=v.findViewById(R.id.tvSaleDate); tvTotal=v.findViewById(R.id.tvSaleTotal); tvQty=v.findViewById(R.id.tvSaleQty); tvNotes=v.findViewById(R.id.tvSaleNotes); }
    }
}
