package com.storepilot.inventory;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.storepilot.R;
import com.storepilot.models.Product;
import java.util.*;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ViewHolder> {

    public interface OnProductClickListener { void onProductClick(Product product); }

    private List<Product> products = new ArrayList<>();
    private final OnProductClickListener listener;

    public ProductListAdapter(OnProductClickListener listener) { this.listener = listener; }

    public void setProducts(List<Product> list) {
        this.products = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Product p = products.get(position);
        h.tvName.setText(p.getName());
        h.tvCategory.setText(p.getCategory());
        h.tvQty.setText(String.valueOf(p.getQuantity()));
        h.tvPrice.setText(String.format("$%.2f", p.getPrice()));
        h.itemView.setOnClickListener(v -> listener.onProductClick(p));
    }

    @Override public int getItemCount() { return products.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvQty, tvPrice;
        ViewHolder(View v) {
            super(v);
            tvName     = v.findViewById(R.id.tvProductName);
            tvCategory = v.findViewById(R.id.tvProductCategory);
            tvQty      = v.findViewById(R.id.tvProductQuantity);
            tvPrice    = v.findViewById(R.id.tvProductPrice);
        }
    }
}
