package com.storepilot.sales;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.storepilot.R;
import com.storepilot.viewmodels.SaleViewModel;

public class SalesHistoryFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_sales_history, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerSales);
        SaleAdapter adapter = new SaleAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        SaleViewModel vm = new ViewModelProvider(this).get(SaleViewModel.class);
        vm.getAllSales().observe(getViewLifecycleOwner(), adapter::setSales);

        view.findViewById(R.id.fabAddSale).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), AddSaleActivity.class)));
    }
}
