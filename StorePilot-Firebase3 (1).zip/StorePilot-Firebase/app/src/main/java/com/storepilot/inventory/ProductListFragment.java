package com.storepilot.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.storepilot.R;
import com.storepilot.core.PermissionManager;
import com.storepilot.viewmodels.ProductViewModel;

public class ProductListFragment extends Fragment {

    private ProductViewModel productViewModel;
    private ProductListAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recycler = view.findViewById(R.id.recyclerProducts);
        FloatingActionButton fabAdd = view.findViewById(R.id.fabAddProduct);

        adapter = new ProductListAdapter(product -> {
            ProductDetailsFragment details = ProductDetailsFragment.newInstance(product.getId());
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, details)
                    .addToBackStack(null).commit();
        });
        recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        recycler.setAdapter(adapter);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        productViewModel.getAllProducts().observe(getViewLifecycleOwner(), adapter::setProducts);

        fabAdd.setVisibility(PermissionManager.currentUserHasPermission(PermissionManager.MANAGE_PRODUCTS)
                ? View.VISIBLE : View.GONE);
        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), AddEditProductActivity.class)));
    }
}
