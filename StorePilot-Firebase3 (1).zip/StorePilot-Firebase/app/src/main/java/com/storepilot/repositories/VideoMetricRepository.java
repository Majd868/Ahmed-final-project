package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.VideoMetric;

import java.util.ArrayList;
import java.util.List;

public class VideoMetricRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    public LiveData<List<VideoMetric>> getAllMetrics() {
        MutableLiveData<List<VideoMetric>> ld = new MutableLiveData<>();
        fm.metricsCollection()
                .orderBy("videoDate", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(VideoMetric.class));
                });
        return ld;
    }

    public LiveData<Boolean> insert(VideoMetric metric) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.metricsCollection().add(metric)
                .addOnSuccessListener(r -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> update(VideoMetric metric) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.metricsCollection().document(metric.getId()).set(metric)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(VideoMetric metric) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.metricsCollection().document(metric.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }
}
