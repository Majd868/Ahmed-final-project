package com.storepilot.admin;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.storepilot.R;
import com.storepilot.models.User;
import com.storepilot.repositories.UserRepository;
import java.util.*;

public class UserManagementFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_user_management, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerUsers);
        UserAdapter adapter = new UserAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        UserRepository repo = new UserRepository();
        repo.getAllUsers().observe(getViewLifecycleOwner(), adapter::setUsers);
    }
}

class UserAdapter extends RecyclerView.Adapter<UserAdapter.VH> {
    private List<User> list = new ArrayList<>();
    public void setUsers(List<User> l) { list = l != null ? l : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_user, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        User u = list.get(pos);
        h.tvUsername.setText(u.getUsername());
        h.tvRole.setText(u.getRole());
    }
    @Override public int getItemCount() { return list.size(); }
    static class VH extends RecyclerView.ViewHolder {
        TextView tvUsername, tvRole;
        VH(View v) { super(v); tvUsername=v.findViewById(R.id.tvUsername); tvRole=v.findViewById(R.id.tvUserRole); }
    }
}
