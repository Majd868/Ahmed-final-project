package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class VideoMetric {

    @DocumentId
    private String id;
    private String title;
    private String platform;
    private long views;
    private long likes;
    private long shares;
    private long comments;
    private String recordedBy;

    @ServerTimestamp
    private Date videoDate;

    public VideoMetric() {}

    public VideoMetric(String title, String platform, long views, long likes,
                       long shares, long comments, String recordedBy) {
        this.title = title;
        this.platform = platform;
        this.views = views;
        this.likes = likes;
        this.shares = shares;
        this.comments = comments;
        this.recordedBy = recordedBy;
    }

    public String getId() { return id; }
    public void setId(String v) { this.id = v; }
    public String getTitle() { return title; }
    public void setTitle(String v) { this.title = v; }
    public String getPlatform() { return platform; }
    public void setPlatform(String v) { this.platform = v; }
    public long getViews() { return views; }
    public void setViews(long v) { this.views = v; }
    public long getLikes() { return likes; }
    public void setLikes(long v) { this.likes = v; }
    public long getShares() { return shares; }
    public void setShares(long v) { this.shares = v; }
    public long getComments() { return comments; }
    public void setComments(long v) { this.comments = v; }
    public String getRecordedBy() { return recordedBy; }
    public void setRecordedBy(String v) { this.recordedBy = v; }
    public Date getVideoDate() { return videoDate; }
    public void setVideoDate(Date v) { this.videoDate = v; }
}
