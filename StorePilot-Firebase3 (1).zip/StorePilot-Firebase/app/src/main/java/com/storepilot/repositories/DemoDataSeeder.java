package com.storepilot.repositories;

import com.google.firebase.Timestamp;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Product;
import com.storepilot.models.Sale;
import com.storepilot.models.User;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * DemoDataSeeder - يضيف بيانات تجريبية إلى Firebase
 * يُستدعى عند تفعيل Demo Mode في الإعداد الأولي
 */
public class DemoDataSeeder {

    private final FirebaseManager fm;
    private final String ownerUid;
    private final String ownerUsername;

    public DemoDataSeeder(FirebaseManager fm, String ownerUid, String ownerUsername) {
        this.fm = fm;
        this.ownerUid = ownerUid;
        this.ownerUsername = ownerUsername;
    }

    public void seed() {
        seedProducts();
        seedSales();
        seedSeasons();
        seedTasks();
        initRealtimeDashboard();
    }

    private void seedProducts() {
        String[][] products = {
            {"Classic White T-Shirt", "Tops",     "M",  "White", "50", "29.99", "10.00"},
            {"Slim Fit Jeans",        "Bottoms",  "32", "Blue",  "30", "79.99", "35.00"},
            {"Floral Summer Dress",   "Dresses",  "S",  "Red",   "20", "59.99", "22.00"},
            {"Leather Jacket",        "Outerwear","L",  "Black", "5",  "199.99","90.00"},
            {"Casual Sneakers",       "Footwear", "42", "White", "15", "89.99", "40.00"},
        };

        for (String[] p : products) {
            Product product = new Product(
                p[0], p[1], p[2], p[3],
                Integer.parseInt(p[4]),
                Double.parseDouble(p[5]),
                Double.parseDouble(p[6]),
                ""
            );
            fm.productsCollection().add(product);
        }
    }

    private void seedSales() {
        // مبيعات اليوم
        Sale sale1 = new Sale(
            "demo_product_1", "Classic White T-Shirt",
            3, 89.97, ownerUid, ownerUsername, "Walk-in customer"
        );
        fm.salesCollection().add(sale1).addOnSuccessListener(ref -> {
            // تحديث إجمالي اليوم في Realtime DB
            String todayKey = getTodayKey();
            fm.dashboardRef().child("daily_sales").child(todayKey).setValue(89.97);
        });
    }

    private void seedSeasons() {
        Map<String, Object> summer = new HashMap<>();
        summer.put("name", "Summer 2024");
        summer.put("isActive", true);
        summer.put("alertDaysBeforeEnd", 30);
        summer.put("notes", "Current season");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        summer.put("startDate", new Timestamp(cal.getTime()));
        cal.add(Calendar.MONTH, 2);
        summer.put("endDate", new Timestamp(cal.getTime()));

        fm.seasonsCollection().add(summer);

        Map<String, Object> fall = new HashMap<>();
        fall.put("name", "Fall 2024");
        fall.put("isActive", false);
        fall.put("alertDaysBeforeEnd", 30);
        fall.put("notes", "Upcoming season");

        cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, 1);
        fall.put("startDate", new Timestamp(cal.getTime()));
        cal.add(Calendar.MONTH, 3);
        fall.put("endDate", new Timestamp(cal.getTime()));

        fm.seasonsCollection().add(fall);
    }

    private void seedTasks() {
        Map<String, Object> task1 = new HashMap<>();
        task1.put("title", "Restock low inventory");
        task1.put("description", "Check and reorder products below 10 units");
        task1.put("assignedTo", ownerUid);
        task1.put("assignedToName", ownerUsername);
        task1.put("createdBy", ownerUid);
        task1.put("status", "TODO");
        task1.put("priority", "HIGH");
        task1.put("isPrivate", false);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 3);
        task1.put("dueDate", new Timestamp(cal.getTime()));

        fm.tasksCollection().add(task1);

        Map<String, Object> task2 = new HashMap<>();
        task2.put("title", "Monthly sales report");
        task2.put("description", "Prepare report for owner review");
        task2.put("assignedTo", ownerUid);
        task2.put("assignedToName", ownerUsername);
        task2.put("createdBy", ownerUid);
        task2.put("status", "IN_PROGRESS");
        task2.put("priority", "MEDIUM");
        task2.put("isPrivate", false);
        cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 7);
        task2.put("dueDate", new Timestamp(cal.getTime()));

        fm.tasksCollection().add(task2);
    }

    private void initRealtimeDashboard() {
        // تهيئة بنية Realtime Database
        Map<String, Object> stats = new HashMap<>();
        stats.put("productCount", 5L);
        stats.put("totalUsers", 1L);
        stats.put("lastUpdated", System.currentTimeMillis());
        fm.storeStatsRef().setValue(stats);
    }

    private String getTodayKey() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.YEAR) + "-"
                + (cal.get(Calendar.MONTH) + 1) + "-"
                + cal.get(Calendar.DAY_OF_MONTH);
    }
}
