package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Product;
import com.storepilot.repositories.ProductRepository;
import java.util.List;

public class ProductViewModel extends AndroidViewModel {
    private final ProductRepository repo;

    public ProductViewModel(@NonNull Application app) {
        super(app);
        repo = new ProductRepository();
    }

    public LiveData<List<Product>> getAllProducts() { return repo.getAllProducts(); }
    public LiveData<Product> getById(String id) { return repo.getById(id); }
    public LiveData<List<Product>> getLowStockProducts(int threshold) { return repo.getLowStockProducts(threshold); }
    public LiveData<Boolean> insert(Product p) { return repo.insert(p); }
    public LiveData<Boolean> update(Product p) { return repo.update(p); }
    public LiveData<Boolean> delete(Product p) { return repo.delete(p); }
    public void updateQuantity(String id, int qty) { repo.updateQuantity(id, qty); }
}
