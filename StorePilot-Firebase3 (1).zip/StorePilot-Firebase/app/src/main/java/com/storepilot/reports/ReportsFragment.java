// ==================== ReportsFragment ====================
package com.storepilot.reports;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.*;
import com.google.android.material.chip.Chip;
import com.storepilot.R;
import com.storepilot.viewmodels.ReportsViewModel;
import java.text.NumberFormat;
import java.util.Locale;

public class ReportsFragment extends Fragment {
    private MutableLiveData<Integer> filterMode = new MutableLiveData<>(1);
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_reports, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView tvTotal = view.findViewById(R.id.tvReportSalesTotal);
        Chip chipWeek=view.findViewById(R.id.chipWeek), chipMonth=view.findViewById(R.id.chipMonth), chipYear=view.findViewById(R.id.chipYear);
        ReportsViewModel vm = new ViewModelProvider(this).get(ReportsViewModel.class);
        LiveData<Double> data = Transformations.switchMap(filterMode, mode -> {
            if (mode==0) return vm.getSalesTotalByWeek();
            if (mode==2) return vm.getSalesTotalByYear();
            return vm.getSalesTotalByMonth();
        });
        data.observe(getViewLifecycleOwner(), total ->
                tvTotal.setText(NumberFormat.getCurrencyInstance(Locale.US).format(total != null ? total : 0.0)));
        chipWeek.setOnClickListener(v -> filterMode.setValue(0));
        chipMonth.setOnClickListener(v -> filterMode.setValue(1));
        chipYear.setOnClickListener(v -> filterMode.setValue(2));
        chipMonth.setChecked(true);
    }
}
