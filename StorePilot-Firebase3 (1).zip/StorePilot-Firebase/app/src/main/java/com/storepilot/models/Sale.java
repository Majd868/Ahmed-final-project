package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class Sale {

    @DocumentId
    private String id;
    private String productId;
    private String productName;
    private int quantity;
    private double totalPrice;
    private String soldBy;
    private String soldByName;
    private String notes;

    @ServerTimestamp
    private Date saleDate;

    public Sale() {}

    public Sale(String productId, String productName, int quantity,
                double totalPrice, String soldBy, String soldByName, String notes) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.soldBy = soldBy;
        this.soldByName = soldByName;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProductId() { return productId; }
    public void setProductId(String v) { this.productId = v; }
    public String getProductName() { return productName; }
    public void setProductName(String v) { this.productName = v; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int v) { this.quantity = v; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double v) { this.totalPrice = v; }
    public String getSoldBy() { return soldBy; }
    public void setSoldBy(String v) { this.soldBy = v; }
    public String getSoldByName() { return soldByName; }
    public void setSoldByName(String v) { this.soldByName = v; }
    public String getNotes() { return notes; }
    public void setNotes(String v) { this.notes = v; }
    public Date getSaleDate() { return saleDate; }
    public void setSaleDate(Date v) { this.saleDate = v; }
}
