// ==================== VideoMetricsFragment ====================
package com.storepilot.marketing;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.VideoMetric;
import com.storepilot.repositories.SessionManager;
import com.storepilot.viewmodels.VideoMetricViewModel;
import java.text.NumberFormat;
import java.util.*;

public class VideoMetricsFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_video_metrics, c, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerVideoMetrics);
        FloatingActionButton fab = view.findViewById(R.id.fabAddMetric);
        VideoMetricAdapter adapter = new VideoMetricAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        VideoMetricViewModel vm = new ViewModelProvider(this).get(VideoMetricViewModel.class);
        vm.getAllMetrics().observe(getViewLifecycleOwner(), adapter::setMetrics);
        fab.setOnClickListener(v -> startActivity(new Intent(getActivity(), AddMetricActivity.class)));
    }
}

class VideoMetricAdapter extends RecyclerView.Adapter<VideoMetricAdapter.VH> {
    private List<VideoMetric> list = new ArrayList<>();
    public void setMetrics(List<VideoMetric> l) { list = l != null ? l : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_video_metric, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        VideoMetric m = list.get(pos);
        h.tvTitle.setText(m.getTitle());
        h.tvPlatform.setText(m.getPlatform());
        h.tvViews.setText(NumberFormat.getNumberInstance(Locale.US).format(m.getViews()));
        h.tvLikes.setText(NumberFormat.getNumberInstance(Locale.US).format(m.getLikes()));
    }
    @Override public int getItemCount() { return list.size(); }
    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvPlatform, tvViews, tvLikes;
        VH(View v) { super(v); tvTitle=v.findViewById(R.id.tvMetricTitle); tvPlatform=v.findViewById(R.id.tvMetricPlatform); tvViews=v.findViewById(R.id.tvMetricViews); tvLikes=v.findViewById(R.id.tvMetricLikes); }
    }
}

class AddMetricActivity extends BaseActivity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_add_metric);
        EditText etTitle=findViewById(R.id.etMetricTitle), etPlatform=findViewById(R.id.etMetricPlatform),
                etViews=findViewById(R.id.etMetricViews), etLikes=findViewById(R.id.etMetricLikes),
                etShares=findViewById(R.id.etMetricShares), etComments=findViewById(R.id.etMetricComments);
        VideoMetricViewModel vm = new ViewModelProvider(this).get(VideoMetricViewModel.class);
        findViewById(R.id.btnSaveMetric).setOnClickListener(v -> {
            String title=etTitle.getText().toString().trim(), platform=etPlatform.getText().toString().trim();
            if (title.isEmpty()||platform.isEmpty()) { Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show(); return; }
            String uid = SessionManager.getInstance().getCurrentUserId();
            long views=Long.parseLong(etViews.getText().toString().isEmpty()?"0":etViews.getText().toString());
            long likes=Long.parseLong(etLikes.getText().toString().isEmpty()?"0":etLikes.getText().toString());
            long shares=Long.parseLong(etShares.getText().toString().isEmpty()?"0":etShares.getText().toString());
            long comments=Long.parseLong(etComments.getText().toString().isEmpty()?"0":etComments.getText().toString());
            VideoMetric m = new VideoMetric(title, platform, views, likes, shares, comments, uid);
            vm.insert(m).observe(this, ok -> { if (Boolean.TRUE.equals(ok)) finish(); });
        });
    }
}
