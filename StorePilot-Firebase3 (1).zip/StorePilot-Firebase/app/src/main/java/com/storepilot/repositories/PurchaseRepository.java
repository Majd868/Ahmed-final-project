// ==================== PurchaseRepository.java ====================
package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Purchase;
import java.util.ArrayList;
import java.util.List;

public class PurchaseRepository {
    private final FirebaseManager fm = FirebaseManager.getInstance();

    public LiveData<List<Purchase>> getAllPurchases() {
        MutableLiveData<List<Purchase>> ld = new MutableLiveData<>();
        fm.purchasesCollection()
                .orderBy("purchaseDate", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Purchase.class));
                });
        return ld;
    }

    public LiveData<Boolean> insert(Purchase purchase) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.purchasesCollection().add(purchase)
                .addOnSuccessListener(r -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> update(Purchase purchase) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.purchasesCollection().document(purchase.getId()).set(purchase)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(Purchase purchase) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.purchasesCollection().document(purchase.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }
}
