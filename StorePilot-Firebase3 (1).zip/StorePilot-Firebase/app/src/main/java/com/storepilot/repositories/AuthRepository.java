package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.User;

/**
 * AuthRepository
 *
 * يستبدل UserRepository + CryptoUtil + SessionManager القديمة.
 * Firebase Authentication يتولى كل شيء:
 * - تسجيل المستخدمين (email/password)
 * - التحقق من كلمة المرور (Firebase يديرها آمنياً)
 * - الجلسة (تُحفظ تلقائياً حتى بعد إغلاق التطبيق)
 */
public class AuthRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();
    private final FirebaseAuth auth = fm.getAuth();

    // ========== التحقق من الحالة ==========

    public boolean isLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    public String getCurrentUserId() {
        return fm.getCurrentUserId();
    }

    /**
     * هل يوجد OWNER في النظام؟
     * يُستخدم لتحديد إذا كان يجب إظهار شاشة الإعداد أم لا.
     */
    public LiveData<Boolean> checkOwnerExists() {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.usersCollection()
                .whereEqualTo("role", "OWNER")
                .limit(1)
                .get()
                .addOnSuccessListener(snap -> result.setValue(!snap.isEmpty()))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    // ========== تسجيل الدخول ==========

    /**
     * login باستخدام Firebase Authentication
     * البريد الإلكتروني = username@storepilot.com (نبني البريد من اسم المستخدم)
     */
    public LiveData<AuthResult> login(String username, String password) {
        MutableLiveData<AuthResult> result = new MutableLiveData<>();
        String email = buildEmail(username);

        auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    // جلب بيانات المستخدم من Firestore
                    String uid = authResult.getUser().getUid();
                    loadUserProfile(uid, result);
                })
                .addOnFailureListener(e -> {
                    result.setValue(AuthResult.error("اسم المستخدم أو كلمة المرور غير صحيحة"));
                });

        return result;
    }

    // ========== إنشاء حساب المالك (Setup) ==========

    public LiveData<AuthResult> setupOwner(String username, String password, boolean demoMode) {
        MutableLiveData<AuthResult> result = new MutableLiveData<>();
        String email = buildEmail(username);

        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    String uid = authResult.getUser().getUid();
                    User owner = new User(uid, username, email, "OWNER");

                    // حفظ بيانات المالك في Firestore
                    fm.usersCollection().document(uid).set(owner)
                            .addOnSuccessListener(v -> {
                                SessionManager.getInstance().setCurrentUser(owner);
                                if (demoMode) {
                                    seedDemoData(uid, username);
                                }
                                result.setValue(AuthResult.success(owner));
                            })
                            .addOnFailureListener(e -> result.setValue(
                                    AuthResult.error("فشل في حفظ بيانات المستخدم: " + e.getMessage())));
                })
                .addOnFailureListener(e -> result.setValue(
                        AuthResult.error("فشل في إنشاء الحساب: " + e.getMessage())));

        return result;
    }

    // ========== إنشاء حساب موظف (من قِبل المالك) ==========

    public LiveData<AuthResult> createEmployee(String username, String password, String role) {
        MutableLiveData<AuthResult> result = new MutableLiveData<>();
        String email = buildEmail(username);

        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    String uid = authResult.getUser().getUid();
                    User employee = new User(uid, username, email, role);

                    fm.usersCollection().document(uid).set(employee)
                            .addOnSuccessListener(v -> result.setValue(AuthResult.success(employee)))
                            .addOnFailureListener(e -> result.setValue(
                                    AuthResult.error("فشل في حفظ بيانات الموظف")));
                })
                .addOnFailureListener(e -> result.setValue(
                        AuthResult.error("فشل في إنشاء الحساب: " + e.getMessage())));

        return result;
    }

    // ========== تسجيل الخروج ==========

    public void logout() {
        SessionManager.getInstance().clearUser();
        auth.signOut();
    }

    // ========== Helper Methods ==========

    /**
     * Firebase Auth يستخدم البريد الإلكتروني.
     * نحول اسم المستخدم إلى بريد داخلي للتطبيق.
     */
    private String buildEmail(String username) {
        return username.toLowerCase().trim() + "@storepilot.app";
    }

    private void loadUserProfile(String uid, MutableLiveData<AuthResult> result) {
        fm.usersCollection().document(uid).get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        User user = doc.toObject(User.class);
                        if (user != null) {
                            user.setId(uid);
                            SessionManager.getInstance().setCurrentUser(user);
                            result.setValue(AuthResult.success(user));
                        } else {
                            result.setValue(AuthResult.error("بيانات المستخدم تالفة"));
                        }
                    } else {
                        result.setValue(AuthResult.error("المستخدم غير موجود في قاعدة البيانات"));
                    }
                })
                .addOnFailureListener(e -> result.setValue(
                        AuthResult.error("فشل تحميل بيانات المستخدم")));
    }

    private void seedDemoData(String ownerUid, String ownerUsername) {
        // إضافة بيانات تجريبية عند تفعيل Demo Mode
        new DemoDataSeeder(fm, ownerUid, ownerUsername).seed();
    }

    // ========== AuthResult Wrapper ==========

    public static class AuthResult {
        public final boolean isSuccess;
        public final User user;
        public final String errorMessage;

        private AuthResult(boolean isSuccess, User user, String errorMessage) {
            this.isSuccess = isSuccess;
            this.user = user;
            this.errorMessage = errorMessage;
        }

        public static AuthResult success(User user) {
            return new AuthResult(true, user, null);
        }

        public static AuthResult error(String message) {
            return new AuthResult(false, null, message);
        }
    }
}
