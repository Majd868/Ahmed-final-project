package com.storepilot.inventory;

import android.os.Bundle;
import android.widget.*;
import androidx.lifecycle.ViewModelProvider;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.Product;
import com.storepilot.viewmodels.ProductViewModel;

public class AddEditProductActivity extends BaseActivity {

    public static final String EXTRA_PRODUCT_ID = "product_id";

    private EditText etName, etCategory, etSize, etColor, etQty, etPrice, etCost;
    private ProductViewModel vm;
    private Product existing = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_product);

        etName     = findViewById(R.id.etProductName);
        etCategory = findViewById(R.id.etProductCategory);
        etSize     = findViewById(R.id.etProductSize);
        etColor    = findViewById(R.id.etProductColor);
        etQty      = findViewById(R.id.etProductQuantity);
        etPrice    = findViewById(R.id.etProductPrice);
        etCost     = findViewById(R.id.etProductCostPrice);

        vm = new ViewModelProvider(this).get(ProductViewModel.class);

        String productId = getIntent().getStringExtra(EXTRA_PRODUCT_ID);
        if (productId != null) {
            vm.getById(productId).observe(this, product -> {
                if (product != null && existing == null) {
                    existing = product;
                    etName.setText(product.getName());
                    etCategory.setText(product.getCategory());
                    etSize.setText(product.getSize());
                    etColor.setText(product.getColor());
                    etQty.setText(String.valueOf(product.getQuantity()));
                    etPrice.setText(String.valueOf(product.getPrice()));
                    etCost.setText(String.valueOf(product.getCostPrice()));
                }
            });
        }

        findViewById(R.id.btnSaveProduct).setOnClickListener(v -> save());
    }

    private void save() {
        String name  = etName.getText().toString().trim();
        String qtyS  = etQty.getText().toString().trim();
        String priceS = etPrice.getText().toString().trim();

        if (name.isEmpty() || qtyS.isEmpty() || priceS.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show();
            return;
        }

        int qty    = Integer.parseInt(qtyS);
        double price = Double.parseDouble(priceS);
        double cost  = etCost.getText().toString().isEmpty() ? 0 : Double.parseDouble(etCost.getText().toString());

        if (existing != null) {
            existing.setName(name);
            existing.setCategory(etCategory.getText().toString().trim());
            existing.setSize(etSize.getText().toString().trim());
            existing.setColor(etColor.getText().toString().trim());
            existing.setQuantity(qty);
            existing.setPrice(price);
            existing.setCostPrice(cost);
            vm.update(existing);
        } else {
            Product p = new Product(name, etCategory.getText().toString().trim(),
                    etSize.getText().toString().trim(), etColor.getText().toString().trim(),
                    qty, price, cost, "");
            vm.insert(p);
        }
        finish();
    }
}
