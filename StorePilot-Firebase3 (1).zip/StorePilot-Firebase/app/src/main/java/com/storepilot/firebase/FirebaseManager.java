package com.storepilot.firebase;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * FirebaseManager - مدير مركزي للوصول إلى خدمات Firebase
 *
 * الاستخدام:
 * - FirebaseAuth       → تسجيل الدخول والمصادقة
 * - Firestore          → قاعدة البيانات الرئيسية (Products, Sales, etc.)
 * - Realtime Database  → البيانات الفورية (Dashboard, Online users)
 * - Storage            → صور المنتجات
 */
public class FirebaseManager {

    private static FirebaseManager instance;

    private final FirebaseAuth auth;
    private final FirebaseFirestore firestore;
    private final FirebaseDatabase realtimeDb;
    private final FirebaseStorage storage;

    // ========== Firestore Collections ==========
    public static final String COLLECTION_USERS      = "users";
    public static final String COLLECTION_PRODUCTS   = "products";
    public static final String COLLECTION_SALES      = "sales";
    public static final String COLLECTION_PURCHASES  = "purchases";
    public static final String COLLECTION_TASKS      = "tasks";
    public static final String COLLECTION_SEASONS    = "seasons";
    public static final String COLLECTION_METRICS    = "video_metrics";

    // ========== Realtime DB Paths ==========
    public static final String RT_DASHBOARD          = "dashboard";
    public static final String RT_ONLINE_USERS       = "online_users";
    public static final String RT_STORE_STATS        = "store_stats";

    private FirebaseManager() {
        auth = FirebaseAuth.getInstance();

        // إعدادات Firestore مع دعم الكاش المحلي (offline support)
        firestore = FirebaseFirestore.getInstance();
        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                .build();
        firestore.setFirestoreSettings(settings);

        // Realtime Database
        realtimeDb = FirebaseDatabase.getInstance();
        realtimeDb.setPersistenceEnabled(true);

        storage = FirebaseStorage.getInstance();
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            instance = new FirebaseManager();
        }
        return instance;
    }

    // ========== Getters ==========

    public FirebaseAuth getAuth() {
        return auth;
    }

    public FirebaseFirestore getFirestore() {
        return firestore;
    }

    public FirebaseDatabase getRealtimeDb() {
        return realtimeDb;
    }

    public FirebaseStorage getStorage() {
        return storage;
    }

    // ========== Shortcut References ==========

    public com.google.firebase.firestore.CollectionReference usersCollection() {
        return firestore.collection(COLLECTION_USERS);
    }

    public com.google.firebase.firestore.CollectionReference productsCollection() {
        return firestore.collection(COLLECTION_PRODUCTS);
    }

    public com.google.firebase.firestore.CollectionReference salesCollection() {
        return firestore.collection(COLLECTION_SALES);
    }

    public com.google.firebase.firestore.CollectionReference purchasesCollection() {
        return firestore.collection(COLLECTION_PURCHASES);
    }

    public com.google.firebase.firestore.CollectionReference tasksCollection() {
        return firestore.collection(COLLECTION_TASKS);
    }

    public com.google.firebase.firestore.CollectionReference seasonsCollection() {
        return firestore.collection(COLLECTION_SEASONS);
    }

    public com.google.firebase.firestore.CollectionReference metricsCollection() {
        return firestore.collection(COLLECTION_METRICS);
    }

    public DatabaseReference dashboardRef() {
        return realtimeDb.getReference(RT_DASHBOARD);
    }

    public DatabaseReference storeStatsRef() {
        return realtimeDb.getReference(RT_STORE_STATS);
    }

    public DatabaseReference onlineUsersRef() {
        return realtimeDb.getReference(RT_ONLINE_USERS);
    }

    public StorageReference productImagesRef() {
        return storage.getReference().child("product_images");
    }

    // ========== Auth Helpers ==========

    public boolean isLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    public String getCurrentUserId() {
        if (auth.getCurrentUser() != null) {
            return auth.getCurrentUser().getUid();
        }
        return null;
    }

    public void signOut() {
        auth.signOut();
    }
}
