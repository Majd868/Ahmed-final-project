package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class Task {

    @DocumentId
    private String id;
    private String title;
    private String description;
    private String assignedTo;
    private String assignedToName;
    private String createdBy;
    private String status;   // TODO, IN_PROGRESS, DONE
    private String priority; // LOW, MEDIUM, HIGH
    private boolean isPrivate;
    private Date dueDate;

    @ServerTimestamp
    private Date createdAt;

    public Task() {}

    public Task(String title, String description, String assignedTo, String assignedToName,
                String createdBy, String status, String priority, boolean isPrivate, Date dueDate) {
        this.title = title;
        this.description = description;
        this.assignedTo = assignedTo;
        this.assignedToName = assignedToName;
        this.createdBy = createdBy;
        this.status = status;
        this.priority = priority;
        this.isPrivate = isPrivate;
        this.dueDate = dueDate;
    }

    public String getId() { return id; }
    public void setId(String v) { this.id = v; }
    public String getTitle() { return title; }
    public void setTitle(String v) { this.title = v; }
    public String getDescription() { return description; }
    public void setDescription(String v) { this.description = v; }
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String v) { this.assignedTo = v; }
    public String getAssignedToName() { return assignedToName; }
    public void setAssignedToName(String v) { this.assignedToName = v; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String v) { this.createdBy = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public String getPriority() { return priority; }
    public void setPriority(String v) { this.priority = v; }
    public boolean isPrivate() { return isPrivate; }
    public void setPrivate(boolean v) { this.isPrivate = v; }
    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date v) { this.dueDate = v; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date v) { this.createdAt = v; }
}
