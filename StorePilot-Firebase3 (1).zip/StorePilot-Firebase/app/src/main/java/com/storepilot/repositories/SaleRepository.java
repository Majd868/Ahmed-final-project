package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.Timestamp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Sale;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * SaleRepository
 *
 * Firestore: تخزين سجلات المبيعات
 * Realtime DB: إجماليات المبيعات اليومية للـ Dashboard (تحديث فوري)
 */
public class SaleRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    // ========== Read ==========

    public LiveData<List<Sale>> getAllSales() {
        MutableLiveData<List<Sale>> liveData = new MutableLiveData<>();

        fm.salesCollection()
                .orderBy("saleDate", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) {
                        liveData.setValue(new ArrayList<>());
                        return;
                    }
                    liveData.setValue(snapshots.toObjects(Sale.class));
                });

        return liveData;
    }

    /**
     * مبيعات اليوم - من Realtime DB للسرعة الفائقة في الـ Dashboard
     */
    public LiveData<Double> getTodaySalesTotal() {
        MutableLiveData<Double> liveData = new MutableLiveData<>(0.0);

        String todayKey = getTodayKey();

        fm.dashboardRef().child("daily_sales").child(todayKey)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        Double value = snapshot.getValue(Double.class);
                        liveData.setValue(value != null ? value : 0.0);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        liveData.setValue(0.0);
                    }
                });

        return liveData;
    }

    /**
     * مبيعات الأسبوع من Firestore
     */
    public LiveData<Double> getSalesTotalByWeek() {
        MutableLiveData<Double> liveData = new MutableLiveData<>(0.0);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date weekStart = cal.getTime();

        fm.salesCollection()
                .whereGreaterThanOrEqualTo("saleDate", new Timestamp(weekStart))
                .get()
                .addOnSuccessListener(snapshots -> {
                    double total = 0;
                    for (Sale sale : snapshots.toObjects(Sale.class)) {
                        total += sale.getTotalPrice();
                    }
                    liveData.setValue(total);
                });

        return liveData;
    }

    /**
     * مبيعات الشهر من Firestore
     */
    public LiveData<Double> getSalesTotalByMonth() {
        MutableLiveData<Double> liveData = new MutableLiveData<>(0.0);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date monthStart = cal.getTime();

        fm.salesCollection()
                .whereGreaterThanOrEqualTo("saleDate", new Timestamp(monthStart))
                .get()
                .addOnSuccessListener(snapshots -> {
                    double total = 0;
                    for (Sale sale : snapshots.toObjects(Sale.class)) {
                        total += sale.getTotalPrice();
                    }
                    liveData.setValue(total);
                });

        return liveData;
    }

    /**
     * مبيعات السنة من Firestore
     */
    public LiveData<Double> getSalesTotalByYear() {
        MutableLiveData<Double> liveData = new MutableLiveData<>(0.0);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_YEAR, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        Date yearStart = cal.getTime();

        fm.salesCollection()
                .whereGreaterThanOrEqualTo("saleDate", new Timestamp(yearStart))
                .get()
                .addOnSuccessListener(snapshots -> {
                    double total = 0;
                    for (Sale sale : snapshots.toObjects(Sale.class)) {
                        total += sale.getTotalPrice();
                    }
                    liveData.setValue(total);
                });

        return liveData;
    }

    // ========== Write ==========

    public LiveData<Boolean> insert(Sale sale) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();

        fm.salesCollection().add(sale)
                .addOnSuccessListener(ref -> {
                    // تحديث الإجمالي اليومي في Realtime DB فوراً
                    updateDailyTotal(sale.getTotalPrice());
                    result.setValue(true);
                })
                .addOnFailureListener(e -> result.setValue(false));

        return result;
    }

    public LiveData<Boolean> update(Sale sale) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.salesCollection().document(sale.getId()).set(sale)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(Sale sale) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.salesCollection().document(sale.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    // ========== Helpers ==========

    /**
     * تحديث إجمالي المبيعات اليومية في Realtime DB
     * يظهر فورياً في Dashboard لجميع المستخدمين
     */
    private void updateDailyTotal(double amount) {
        String todayKey = getTodayKey();
        fm.dashboardRef().child("daily_sales").child(todayKey)
                .get()
                .addOnSuccessListener(snap -> {
                    double current = snap.getValue(Double.class) != null
                            ? snap.getValue(Double.class) : 0.0;
                    fm.dashboardRef().child("daily_sales").child(todayKey)
                            .setValue(current + amount);
                });
    }

    private String getTodayKey() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.YEAR) + "-"
                + (cal.get(Calendar.MONTH) + 1) + "-"
                + cal.get(Calendar.DAY_OF_MONTH);
    }
}
