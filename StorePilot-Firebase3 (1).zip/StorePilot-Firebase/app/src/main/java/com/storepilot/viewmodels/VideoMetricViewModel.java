package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.VideoMetric;
import com.storepilot.repositories.VideoMetricRepository;
import java.util.List;

public class VideoMetricViewModel extends AndroidViewModel {
    private final VideoMetricRepository repo;
    public VideoMetricViewModel(@NonNull Application app) { super(app); repo = new VideoMetricRepository(); }
    public LiveData<List<VideoMetric>> getAllMetrics() { return repo.getAllMetrics(); }
    public LiveData<Boolean> insert(VideoMetric m) { return repo.insert(m); }
    public LiveData<Boolean> update(VideoMetric m) { return repo.update(m); }
    public LiveData<Boolean> delete(VideoMetric m) { return repo.delete(m); }
}
