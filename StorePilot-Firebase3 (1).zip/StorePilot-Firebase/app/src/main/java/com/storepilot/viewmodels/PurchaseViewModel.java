package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Purchase;
import com.storepilot.repositories.PurchaseRepository;
import java.util.List;

public class PurchaseViewModel extends AndroidViewModel {
    private final PurchaseRepository repo;
    public PurchaseViewModel(@NonNull Application app) { super(app); repo = new PurchaseRepository(); }
    public LiveData<List<Purchase>> getAllPurchases() { return repo.getAllPurchases(); }
    public LiveData<Boolean> insert(Purchase p) { return repo.insert(p); }
    public LiveData<Boolean> update(Purchase p) { return repo.update(p); }
    public LiveData<Boolean> delete(Purchase p) { return repo.delete(p); }
}
