package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Task;

import java.util.ArrayList;
import java.util.List;

public class TaskRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    public LiveData<List<Task>> getAllTasks() {
        MutableLiveData<List<Task>> ld = new MutableLiveData<>();
        fm.tasksCollection()
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Task.class));
                });
        return ld;
    }

    /** مهام مُسنَدة لمستخدم معين */
    public LiveData<List<Task>> getTasksByUser(String userId) {
        MutableLiveData<List<Task>> ld = new MutableLiveData<>();
        fm.tasksCollection()
                .whereEqualTo("assignedTo", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Task.class));
                });
        return ld;
    }

    /** المهام العامة (غير خاصة) */
    public LiveData<List<Task>> getTeamTasks() {
        MutableLiveData<List<Task>> ld = new MutableLiveData<>();
        fm.tasksCollection()
                .whereEqualTo("private", false)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Task.class));
                });
        return ld;
    }

    /** المهام الخاصة للمستخدم */
    public LiveData<List<Task>> getPrivateTasks(String userId) {
        MutableLiveData<List<Task>> ld = new MutableLiveData<>();
        fm.tasksCollection()
                .whereEqualTo("private", true)
                .whereEqualTo("createdBy", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(Task.class));
                });
        return ld;
    }

    /** عدد المهام غير المنتهية للمستخدم */
    public LiveData<Integer> getPendingTaskCount(String userId) {
        MutableLiveData<Integer> ld = new MutableLiveData<>(0);
        fm.tasksCollection()
                .whereEqualTo("assignedTo", userId)
                .whereNotEqualTo("status", "DONE")
                .addSnapshotListener((snap, e) -> {
                    ld.setValue(snap != null ? snap.size() : 0);
                });
        return ld;
    }

    public LiveData<Task> getById(String taskId) {
        MutableLiveData<Task> ld = new MutableLiveData<>();
        fm.tasksCollection().document(taskId)
                .addSnapshotListener((doc, e) -> {
                    if (doc != null && doc.exists()) ld.setValue(doc.toObject(Task.class));
                    else ld.setValue(null);
                });
        return ld;
    }

    public LiveData<Boolean> insert(Task task) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.tasksCollection().add(task)
                .addOnSuccessListener(r -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> update(Task task) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.tasksCollection().document(task.getId()).set(task)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(Task task) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.tasksCollection().document(task.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }
}
