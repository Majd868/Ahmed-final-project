package com.storepilot.sales;

import android.os.Bundle;
import android.widget.*;
import androidx.lifecycle.ViewModelProvider;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.Sale;
import com.storepilot.repositories.SessionManager;
import com.storepilot.viewmodels.SaleViewModel;

public class AddSaleActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sale);

        EditText etProductId = findViewById(R.id.etSaleProductId);
        EditText etQty       = findViewById(R.id.etSaleQuantity);
        EditText etTotal     = findViewById(R.id.etSaleTotalPrice);
        EditText etNotes     = findViewById(R.id.etSaleNotes);
        SaleViewModel vm = new ViewModelProvider(this).get(SaleViewModel.class);

        findViewById(R.id.btnSaveSale).setOnClickListener(v -> {
            String pid   = etProductId.getText().toString().trim();
            String qtyS  = etQty.getText().toString().trim();
            String totS  = etTotal.getText().toString().trim();
            if (pid.isEmpty() || qtyS.isEmpty() || totS.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show();
                return;
            }
            String uid      = SessionManager.getInstance().getCurrentUserId();
            String username = SessionManager.getInstance().getCurrentUsername();
            Sale sale = new Sale(pid, "", Integer.parseInt(qtyS), Double.parseDouble(totS),
                    uid, username, etNotes.getText().toString().trim());
            vm.insert(sale).observe(this, ok -> { if (Boolean.TRUE.equals(ok)) finish(); });
        });
    }
}
