package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Product;
import com.storepilot.repositories.ProductRepository;
import com.storepilot.repositories.SaleRepository;
import java.util.List;

public class ReportsViewModel extends AndroidViewModel {
    private final SaleRepository saleRepo;
    private final ProductRepository productRepo;

    public ReportsViewModel(@NonNull Application app) {
        super(app);
        saleRepo = new SaleRepository();
        productRepo = new ProductRepository();
    }

    public LiveData<Double> getSalesTotalByWeek() { return saleRepo.getSalesTotalByWeek(); }
    public LiveData<Double> getSalesTotalByMonth() { return saleRepo.getSalesTotalByMonth(); }
    public LiveData<Double> getSalesTotalByYear() { return saleRepo.getSalesTotalByYear(); }
    public LiveData<List<Product>> getLowStockProducts(int threshold) { return productRepo.getLowStockProducts(threshold); }
}
