package com.storepilot.tasks;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.*;
import androidx.recyclerview.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.storepilot.R;
import com.storepilot.core.BaseActivity;
import com.storepilot.models.Task;
import com.storepilot.repositories.SessionManager;
import com.storepilot.viewmodels.TaskViewModel;
import java.text.SimpleDateFormat;
import java.util.*;

public class TaskListFragment extends Fragment {
    private TaskAdapter adapter;
    private TaskViewModel vm;
    private MutableLiveData<Integer> selectedTab = new MutableLiveData<>(0);

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_task_list, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rv = view.findViewById(R.id.recyclerTasks);
        TabLayout tabs = view.findViewById(R.id.tabLayoutTasks);
        FloatingActionButton fab = view.findViewById(R.id.fabAddTask);

        adapter = new TaskAdapter();
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(adapter);
        vm = new ViewModelProvider(this).get(TaskViewModel.class);

        String uid = SessionManager.getInstance().getCurrentUserId();

        LiveData<List<Task>> tasksLiveData = Transformations.switchMap(selectedTab, tab -> {
            if (tab == null || tab == 0) return vm.getTasksByUser(uid);
            if (tab == 1) return vm.getTeamTasks();
            return vm.getPrivateTasks(uid);
        });
        tasksLiveData.observe(getViewLifecycleOwner(), adapter::setTasks);

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab t) { selectedTab.setValue(t.getPosition()); }
            @Override public void onTabUnselected(TabLayout.Tab t) {}
            @Override public void onTabReselected(TabLayout.Tab t) {}
        });

        fab.setOnClickListener(v -> startActivity(new Intent(getActivity(), AddEditTaskActivity.class)));
    }
}

class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.VH> {
    private List<Task> list = new ArrayList<>();
    public void setTasks(List<Task> l) { list = l != null ? l : new ArrayList<>(); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_task, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Task t = list.get(pos);
        h.tvTitle.setText(t.getTitle());
        h.tvStatus.setText(t.getStatus());
        h.tvPriority.setText(t.getPriority());
        h.tvDue.setText(t.getDueDate() != null ? new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(t.getDueDate()) : "No due date");
    }
    @Override public int getItemCount() { return list.size(); }
    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvStatus, tvPriority, tvDue;
        VH(View v) { super(v); tvTitle=v.findViewById(R.id.tvTaskTitle); tvStatus=v.findViewById(R.id.tvTaskStatus); tvPriority=v.findViewById(R.id.tvTaskPriority); tvDue=v.findViewById(R.id.tvTaskDue); }
    }
}

class AddEditTaskActivity extends BaseActivity {
    public static final String EXTRA_TASK_ID = "task_id";
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_add_edit_task);
        EditText etTitle=findViewById(R.id.etTaskTitle), etDesc=findViewById(R.id.etTaskDescription),
                etDue=findViewById(R.id.etTaskDueDate);
        Spinner spinStatus=findViewById(R.id.spinnerTaskStatus), spinPriority=findViewById(R.id.spinnerTaskPriority);
        CheckBox cbPrivate=findViewById(R.id.cbTaskPrivate);
        spinStatus.setAdapter(ArrayAdapter.createFromResource(this, R.array.task_statuses, android.R.layout.simple_spinner_item));
        spinPriority.setAdapter(ArrayAdapter.createFromResource(this, R.array.task_priorities, android.R.layout.simple_spinner_item));
        TaskViewModel vm = new ViewModelProvider(this).get(TaskViewModel.class);
        findViewById(R.id.btnSaveTask).setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            if (title.isEmpty()) { Toast.makeText(this, getString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT).show(); return; }
            String uid  = SessionManager.getInstance().getCurrentUserId();
            String uname= SessionManager.getInstance().getCurrentUsername();
            Task task = new Task(title, etDesc.getText().toString().trim(), uid, uname, uid,
                    spinStatus.getSelectedItem().toString(), spinPriority.getSelectedItem().toString(),
                    cbPrivate.isChecked(), null);
            vm.insert(task).observe(this, ok -> { if (Boolean.TRUE.equals(ok)) finish(); });
        });
    }
}
