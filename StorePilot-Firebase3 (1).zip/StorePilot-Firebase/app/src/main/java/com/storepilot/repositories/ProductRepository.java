package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * ProductRepository - يستخدم Firestore بدلاً من Room
 *
 * الميزات مقارنة بـ Room:
 * - بيانات تُزامَن فورياً عبر جميع الأجهزة
 * - دعم offline تلقائي (Firestore يُخزن نسخة محلية)
 * - لا حاجة لـ ExecutorService أو Threading يدوي
 */
public class ProductRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    // ========== Real-time Listeners (تحل محل LiveData + Room) ==========

    /**
     * جلب جميع المنتجات مع الاستماع للتغييرات الفورية
     */
    public LiveData<List<Product>> getAllProducts() {
        MutableLiveData<List<Product>> liveData = new MutableLiveData<>();

        fm.productsCollection()
                .orderBy("name", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) {
                        liveData.setValue(new ArrayList<>());
                        return;
                    }
                    List<Product> products = snapshots.toObjects(Product.class);
                    liveData.setValue(products);
                });

        return liveData;
    }

    /**
     * جلب المنتجات ذات المخزون المنخفض
     */
    public LiveData<List<Product>> getLowStockProducts(int threshold) {
        MutableLiveData<List<Product>> liveData = new MutableLiveData<>();

        fm.productsCollection()
                .whereLessThanOrEqualTo("quantity", threshold)
                .orderBy("quantity", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) {
                        liveData.setValue(new ArrayList<>());
                        return;
                    }
                    liveData.setValue(snapshots.toObjects(Product.class));
                });

        return liveData;
    }

    /**
     * جلب منتج بالـ ID
     */
    public LiveData<Product> getById(String productId) {
        MutableLiveData<Product> liveData = new MutableLiveData<>();

        fm.productsCollection().document(productId)
                .addSnapshotListener((doc, e) -> {
                    if (e != null || doc == null || !doc.exists()) {
                        liveData.setValue(null);
                        return;
                    }
                    Product product = doc.toObject(Product.class);
                    liveData.setValue(product);
                });

        return liveData;
    }

    // ========== Write Operations ==========

    public LiveData<Boolean> insert(Product product) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();

        fm.productsCollection().add(product)
                .addOnSuccessListener(ref -> {
                    // تحديث عداد المنتجات في Realtime DB
                    updateProductCount(1);
                    result.setValue(true);
                })
                .addOnFailureListener(e -> result.setValue(false));

        return result;
    }

    public LiveData<Boolean> update(Product product) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();

        if (product.getId() == null) {
            result.setValue(false);
            return result;
        }

        fm.productsCollection().document(product.getId()).set(product)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));

        return result;
    }

    public LiveData<Boolean> delete(Product product) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();

        if (product.getId() == null) {
            result.setValue(false);
            return result;
        }

        fm.productsCollection().document(product.getId()).delete()
                .addOnSuccessListener(v -> {
                    updateProductCount(-1);
                    result.setValue(true);
                })
                .addOnFailureListener(e -> result.setValue(false));

        return result;
    }

    /**
     * تحديث الكمية فقط (Atomic update لتجنب Race Conditions)
     */
    public void updateQuantity(String productId, int newQuantity) {
        fm.productsCollection().document(productId)
                .update("quantity", newQuantity);
    }

    // ========== Realtime DB Stats ==========

    private void updateProductCount(int delta) {
        fm.storeStatsRef().child("productCount")
                .get()
                .addOnSuccessListener(snap -> {
                    long current = snap.getValue(Long.class) != null
                            ? snap.getValue(Long.class) : 0L;
                    fm.storeStatsRef().child("productCount").setValue(current + delta);
                });
    }
}
