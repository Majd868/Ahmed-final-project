package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

// ========== Sale ==========
class Sale {

    @DocumentId
    private String id;
    private String productId;       // Firestore document ID
    private String productName;     // denormalized للعرض السريع
    private int quantity;
    private double totalPrice;
    private String soldBy;          // Firebase UID
    private String soldByName;      // denormalized
    private String notes;

    @ServerTimestamp
    private Date saleDate;

    public Sale() {}

    public Sale(String productId, String productName, int quantity,
                double totalPrice, String soldBy, String soldByName, String notes) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.soldBy = soldBy;
        this.soldByName = soldByName;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getSoldBy() { return soldBy; }
    public void setSoldBy(String soldBy) { this.soldBy = soldBy; }
    public String getSoldByName() { return soldByName; }
    public void setSoldByName(String soldByName) { this.soldByName = soldByName; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public Date getSaleDate() { return saleDate; }
    public void setSaleDate(Date saleDate) { this.saleDate = saleDate; }
}

// ========== Purchase ==========
class Purchase {

    @DocumentId
    private String id;
    private String productId;
    private String productName;
    private int quantity;
    private double totalCost;
    private String purchasedBy;
    private String supplier;
    private String notes;

    @ServerTimestamp
    private Date purchaseDate;

    public Purchase() {}

    public Purchase(String productId, String productName, int quantity, double totalCost,
                    String purchasedBy, String supplier, String notes) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.totalCost = totalCost;
        this.purchasedBy = purchasedBy;
        this.supplier = supplier;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }
    public String getProductName() { return productName; }
    public void setProductName(String n) { this.productName = n; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = q; }
    public double getTotalCost() { return totalCost; }
    public void setTotalCost(double c) { this.totalCost = c; }
    public String getPurchasedBy() { return purchasedBy; }
    public void setPurchasedBy(String p) { this.purchasedBy = p; }
    public String getSupplier() { return supplier; }
    public void setSupplier(String s) { this.supplier = s; }
    public String getNotes() { return notes; }
    public void setNotes(String n) { this.notes = n; }
    public Date getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(Date d) { this.purchaseDate = d; }
}

// ========== Task ==========
class Task {

    @DocumentId
    private String id;
    private String title;
    private String description;
    private String assignedTo;      // Firebase UID
    private String assignedToName;
    private String createdBy;
    private String status;          // TODO, IN_PROGRESS, DONE
    private String priority;        // LOW, MEDIUM, HIGH
    private boolean isPrivate;
    private Date dueDate;

    @ServerTimestamp
    private Date createdAt;

    public Task() {}

    public Task(String title, String description, String assignedTo, String assignedToName,
                String createdBy, String status, String priority, boolean isPrivate, Date dueDate) {
        this.title = title;
        this.description = description;
        this.assignedTo = assignedTo;
        this.assignedToName = assignedToName;
        this.createdBy = createdBy;
        this.status = status;
        this.priority = priority;
        this.isPrivate = isPrivate;
        this.dueDate = dueDate;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String t) { this.title = t; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String a) { this.assignedTo = a; }
    public String getAssignedToName() { return assignedToName; }
    public void setAssignedToName(String n) { this.assignedToName = n; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String c) { this.createdBy = c; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public String getPriority() { return priority; }
    public void setPriority(String p) { this.priority = p; }
    public boolean isPrivate() { return isPrivate; }
    public void setPrivate(boolean p) { this.isPrivate = p; }
    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date d) { this.dueDate = d; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date c) { this.createdAt = c; }
}

// ========== Season ==========
class Season {

    @DocumentId
    private String id;
    private String name;
    private Date startDate;
    private Date endDate;
    private int alertDaysBeforeEnd;
    private boolean isActive;
    private String notes;

    public Season() {}

    public Season(String name, Date startDate, Date endDate,
                  int alertDaysBeforeEnd, boolean isActive, String notes) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.alertDaysBeforeEnd = alertDaysBeforeEnd;
        this.isActive = isActive;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public Date getStartDate() { return startDate; }
    public void setStartDate(Date d) { this.startDate = d; }
    public Date getEndDate() { return endDate; }
    public void setEndDate(Date d) { this.endDate = d; }
    public int getAlertDaysBeforeEnd() { return alertDaysBeforeEnd; }
    public void setAlertDaysBeforeEnd(int a) { this.alertDaysBeforeEnd = a; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean a) { this.isActive = a; }
    public String getNotes() { return notes; }
    public void setNotes(String n) { this.notes = n; }
}

// ========== VideoMetric ==========
class VideoMetric {

    @DocumentId
    private String id;
    private String title;
    private String platform;
    private long views;
    private long likes;
    private long shares;
    private long comments;
    private String recordedBy;

    @ServerTimestamp
    private Date videoDate;

    public VideoMetric() {}

    public VideoMetric(String title, String platform, long views, long likes,
                       long shares, long comments, String recordedBy) {
        this.title = title;
        this.platform = platform;
        this.views = views;
        this.likes = likes;
        this.shares = shares;
        this.comments = comments;
        this.recordedBy = recordedBy;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String t) { this.title = t; }
    public String getPlatform() { return platform; }
    public void setPlatform(String p) { this.platform = p; }
    public long getViews() { return views; }
    public void setViews(long v) { this.views = v; }
    public long getLikes() { return likes; }
    public void setLikes(long l) { this.likes = l; }
    public long getShares() { return shares; }
    public void setShares(long s) { this.shares = s; }
    public long getComments() { return comments; }
    public void setComments(long c) { this.comments = c; }
    public String getRecordedBy() { return recordedBy; }
    public void setRecordedBy(String r) { this.recordedBy = r; }
    public Date getVideoDate() { return videoDate; }
    public void setVideoDate(Date d) { this.videoDate = d; }
}
