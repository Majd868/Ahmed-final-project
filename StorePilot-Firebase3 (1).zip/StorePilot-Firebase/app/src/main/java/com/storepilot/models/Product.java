package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class Product {

    @DocumentId
    private String id;
    private String name;
    private String category;
    private String size;
    private String color;
    private int quantity;
    private double price;
    private double costPrice;
    private String imageUrl;    // Firebase Storage URL

    @ServerTimestamp
    private Date createdAt;

    public Product() {}

    public Product(String name, String category, String size, String color,
                   int quantity, double price, double costPrice, String imageUrl) {
        this.name = name;
        this.category = category;
        this.size = size;
        this.color = color;
        this.quantity = quantity;
        this.price = price;
        this.costPrice = costPrice;
        this.imageUrl = imageUrl != null ? imageUrl : "";
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public double getCostPrice() { return costPrice; }
    public void setCostPrice(double costPrice) { this.costPrice = costPrice; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}
