package com.storepilot.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.storepilot.repositories.AuthRepository;
import com.storepilot.repositories.SessionManager;

public class AuthViewModel extends AndroidViewModel {

    private final AuthRepository authRepository;

    public final MutableLiveData<String> loginError    = new MutableLiveData<>();
    public final MutableLiveData<Boolean> loginSuccess = new MutableLiveData<>();
    public final MutableLiveData<Boolean> setupComplete = new MutableLiveData<>();
    public final MutableLiveData<Boolean> needsSetup   = new MutableLiveData<>();
    public final MutableLiveData<Boolean> isLoading    = new MutableLiveData<>(false);

    public AuthViewModel(@NonNull Application application) {
        super(application);
        authRepository = new AuthRepository();
    }

    /**
     * تحقق إذا كان النظام يحتاج إعداداً أولياً (لا يوجد OWNER)
     */
    public void checkNeedsSetup() {
        // إذا كان المستخدم مسجلاً دخوله بالفعل، لا نحتاج للإعداد
        if (SessionManager.getInstance().isLoggedIn()) {
            needsSetup.setValue(false);
            return;
        }

        authRepository.checkOwnerExists().observeForever(ownerExists -> {
            needsSetup.setValue(!ownerExists);
        });
    }

    /**
     * تسجيل الدخول
     */
    public void login(String username, String password) {
        isLoading.setValue(true);

        authRepository.login(username, password).observeForever(result -> {
            isLoading.setValue(false);
            if (result.isSuccess) {
                loginSuccess.setValue(true);
            } else {
                loginError.setValue(result.errorMessage);
            }
        });
    }

    /**
     * إعداد حساب المالك الأولي
     */
    public void setupOwner(String username, String password, boolean demoMode) {
        isLoading.setValue(true);

        authRepository.setupOwner(username, password, demoMode).observeForever(result -> {
            isLoading.setValue(false);
            if (result.isSuccess) {
                setupComplete.setValue(true);
            } else {
                loginError.setValue(result.errorMessage);
            }
        });
    }

    /**
     * إنشاء حساب موظف جديد
     */
    public void createEmployee(String username, String password, String role) {
        isLoading.setValue(true);

        authRepository.createEmployee(username, password, role).observeForever(result -> {
            isLoading.setValue(false);
            if (!result.isSuccess) {
                loginError.setValue(result.errorMessage);
            }
        });
    }

    public void logout() {
        authRepository.logout();
    }
}
