package com.storepilot.models;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class Purchase {

    @DocumentId
    private String id;
    private String productId;
    private String productName;
    private int quantity;
    private double totalCost;
    private String purchasedBy;
    private String supplier;
    private String notes;

    @ServerTimestamp
    private Date purchaseDate;

    public Purchase() {}

    public Purchase(String productId, String productName, int quantity, double totalCost,
                    String purchasedBy, String supplier, String notes) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.totalCost = totalCost;
        this.purchasedBy = purchasedBy;
        this.supplier = supplier;
        this.notes = notes;
    }

    public String getId() { return id; }
    public void setId(String v) { this.id = v; }
    public String getProductId() { return productId; }
    public void setProductId(String v) { this.productId = v; }
    public String getProductName() { return productName; }
    public void setProductName(String v) { this.productName = v; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int v) { this.quantity = v; }
    public double getTotalCost() { return totalCost; }
    public void setTotalCost(double v) { this.totalCost = v; }
    public String getPurchasedBy() { return purchasedBy; }
    public void setPurchasedBy(String v) { this.purchasedBy = v; }
    public String getSupplier() { return supplier; }
    public void setSupplier(String v) { this.supplier = v; }
    public String getNotes() { return notes; }
    public void setNotes(String v) { this.notes = v; }
    public Date getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(Date v) { this.purchaseDate = v; }
}
