package com.storepilot.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.storepilot.firebase.FirebaseManager;
import com.storepilot.models.User;

import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private final FirebaseManager fm = FirebaseManager.getInstance();

    public LiveData<List<User>> getAllUsers() {
        MutableLiveData<List<User>> ld = new MutableLiveData<>();
        fm.usersCollection()
                .orderBy("username")
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) { ld.setValue(new ArrayList<>()); return; }
                    ld.setValue(snap.toObjects(User.class));
                });
        return ld;
    }

    public LiveData<User> getUserById(String uid) {
        MutableLiveData<User> ld = new MutableLiveData<>();
        fm.usersCollection().document(uid)
                .addSnapshotListener((doc, e) -> {
                    if (doc != null && doc.exists()) ld.setValue(doc.toObject(User.class));
                    else ld.setValue(null);
                });
        return ld;
    }

    public LiveData<Boolean> update(User user) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.usersCollection().document(user.getId()).set(user)
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }

    public LiveData<Boolean> delete(User user) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        fm.usersCollection().document(user.getId()).delete()
                .addOnSuccessListener(v -> result.setValue(true))
                .addOnFailureListener(e -> result.setValue(false));
        return result;
    }
}
