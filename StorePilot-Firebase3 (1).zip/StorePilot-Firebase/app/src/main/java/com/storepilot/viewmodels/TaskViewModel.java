package com.storepilot.viewmodels;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.storepilot.models.Task;
import com.storepilot.repositories.TaskRepository;
import java.util.List;

public class TaskViewModel extends AndroidViewModel {
    private final TaskRepository repo;
    public TaskViewModel(@NonNull Application app) { super(app); repo = new TaskRepository(); }
    public LiveData<List<Task>> getAllTasks() { return repo.getAllTasks(); }
    public LiveData<Task> getById(String id) { return repo.getById(id); }
    public LiveData<List<Task>> getTasksByUser(String uid) { return repo.getTasksByUser(uid); }
    public LiveData<List<Task>> getTeamTasks() { return repo.getTeamTasks(); }
    public LiveData<List<Task>> getPrivateTasks(String uid) { return repo.getPrivateTasks(uid); }
    public LiveData<Integer> getPendingTaskCount(String uid) { return repo.getPendingTaskCount(uid); }
    public LiveData<Boolean> insert(Task t) { return repo.insert(t); }
    public LiveData<Boolean> update(Task t) { return repo.update(t); }
    public LiveData<Boolean> delete(Task t) { return repo.delete(t); }
}
